Smurfiki gender party. 15 seconds, 720x1280, 30 fps.
Generated illustrations, original synthesized sound accents. No narration or music.
Render: python render.py closed.png reveal.png
Then python sound.py and mux accents.wav with the rendered MP4 using FFmpeg.
The reference video could not be inspected; this is an original illustrated alternative.
Review: source images and representative rendered frames inspected; full decode successful. Real-time audiovisual playback unavailable.
