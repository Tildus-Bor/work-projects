from PIL import Image, ImageDraw, ImageFont
import numpy as np
import math, random, subprocess, sys, pathlib, wave

ROOT=pathlib.Path(__file__).parent
OUT=pathlib.Path('/workspace/output')
OUT.mkdir(exist_ok=True)
W,H,FPS,DURATION=720,1280,30,15
art=Image.open(sys.argv[1]).convert('RGB')
reveal=Image.open(sys.argv[2]).convert('RGB') if len(sys.argv)>2 else art
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
pink=(255,160,200); blue=(150,218,255)
random.seed(28)
particles=[(random.random(),random.uniform(-1,1),random.uniform(60,150),random.uniform(0,6.28),random.choice([pink,blue,(255,234,190)])) for _ in range(65)]
def clamp(x):return max(0,min(1,x))
def ease(x):return 1-(1-clamp(x))**3
def title(im, lines, y, size=62, color='white', alpha=1):
    layer=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(layer)
    for line in lines:
        f=ImageFont.truetype(BOLD,size)
        while d.textbbox((0,0),line,font=f)[2]>W-100:
            size-=1; f=ImageFont.truetype(BOLD,size)
        d.text((W/2,y),line,font=f,anchor='mt',fill=(*ImageColor(color),int(255*alpha)),stroke_width=0)
        y+=size*1.2
    return Image.alpha_composite(im,layer)
def ImageColor(c):
    if isinstance(c,tuple): return c
    return (255,255,255)
def frame(t):
    # One continuous illustration with three deliberate camera states.
    if t<3.5:
        z=1.04-0.02*ease(t/3.5)
    elif t<7.5:
        z=1.02-0.02*ease((t-3.5)/4)
    else:z=1+0.02*ease((t-7.5)/7.5)
    src=art if t<7.5 else reveal
    scale=W/src.width*z
    a=src.resize((round(src.width*scale),round(src.height*scale)),Image.Resampling.LANCZOS)
    im=Image.new('RGBA',(W,H),(4,14,44,255))
    mask=Image.new('L',a.size,255)
    md=ImageDraw.Draw(mask)
    for yy in range(90):
        md.line((0,yy,a.width,yy),fill=round(255*yy/90))
        md.line((0,a.height-1-yy,a.width,a.height-1-yy),fill=round(255*yy/90))
    im.paste(a,((W-a.width)//2,180-(a.height-1020)//2),mask)
    layer=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(layer)
    # Quiet dark upper scrim keeps all headings readable.
    for yy in range(560):d.line((0,yy,W,yy),fill=(5,12,32,round(85*(1-yy/560))))
    im=Image.alpha_composite(im,layer)
    if t<3.5:
        al=min(ease(t/.4),clamp((3.5-t)/.25))
        im=title(im,['Кого ждём?'],165+25*(1-ease(t/.5)),70,alpha=al)
        im=title(im,['ДЕВОЧКУ ИЛИ МАЛЬЧИКА?'],275,24,blue,al)
    elif t<7.5:
        q=t-3.5; al=min(ease(q/.35),clamp((7.5-t)/.25))
        im=title(im,['Счастье —','разделить','с близкими'],140+18*(1-ease(q/.4)),58,alpha=al)
    else:
        q=t-7.5; al=ease(q/.4)
        im=title(im,['Гендерная','вечеринка'],125+20*(1-al),61,alpha=al)
        im=title(im,['в «Смурфиках»'],285,44,pink,al)
        if t>10.5:
            im=title(im,['Ваш главный сюрприз — у нас'],390,24,blue,ease((t-10.5)/.5))
        if t>12:
            veil=Image.new('RGBA',(W,H)); vd=ImageDraw.Draw(veil)
            vd.rounded_rectangle((50,1098,W-50,1170),radius=25,fill=(5,14,37,220))
            im=Image.alpha_composite(im,veil)
            im=title(im,['Напишите нам • обсудим ваш праздник'],1120,23,alpha=ease((t-12)/.4))
    if 7.5<t<12:
        q=t-7.5; layer=Image.new('RGBA',(W,H)); d=ImageDraw.Draw(layer)
        for x,vx,vy,phase,col in particles:
            xx=W/2+(x-.5)*100+vx*130*q
            yy=820-vy*3.1*q+82*q*q
            if yy<500:continue
            r=3+2*math.sin(phase+q*4)
            d.ellipse((xx-r,yy-r,xx+r,yy+r),fill=(*col,220))
        im=Image.alpha_composite(im,layer)
    return im.convert('RGB')

for t in [1,5,9,13.5]:frame(t).save(ROOT/f'preview-{t}.png')
strip=Image.new('RGB',(W,H//4))
for i,t in enumerate([1,5,9,13.5]): strip.paste(frame(t).resize((W//4,H//4)),(i*W//4,0))
strip.save(OUT/'smurfiki-storyboard.jpg')
cmd=['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(OUT/'smurfiki-gender-party.mp4')]
p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
for n in range(FPS*DURATION):p.stdin.write(frame(n/FPS).tobytes())
p.stdin.close()
if p.wait():raise RuntimeError('ffmpeg render failed')
print(OUT/'smurfiki-gender-party.mp4')
