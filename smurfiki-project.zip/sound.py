import numpy as np, wave, pathlib, subprocess
root=pathlib.Path(__file__).parent
sr=48000
sound=np.zeros(15*sr)
for start,freq,length,amp in [(0.12,660,.32,.08),(3.5,880,.3,.07),(7.5,523,.8,.13),(7.68,659,.8,.10),(7.86,784,1,.10),(12,1047,.65,.08)]:
 t=np.arange(int(length*sr))/sr
 env=(1-np.exp(-t*70))*np.exp(-t*7)
 tone=amp*env*(np.sin(2*np.pi*freq*t)+.22*np.sin(2*np.pi*freq*2*t))
 idx=int(start*sr); sound[idx:idx+len(tone)]+=tone
with wave.open(str(root/'accents.wav'),'wb') as w:
 w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
 w.writeframes((np.repeat(sound[:,None],2,axis=1)*32767).astype('<i2').tobytes())
